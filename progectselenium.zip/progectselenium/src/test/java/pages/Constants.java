package pages;

public class Constants {
    public  final static String addressNext="https://www.next.co.il/he";
    public final static String search_dress="Jeans dress";
    public final static String emailAddress="0583254050tv@gmail.com";
    public final static String password="0583254050tv";
    public final static String cardNumber="1234567898765432";
    public final static String dateMonth="04";
    public final static String dateYear="04";
    public final static String securityCode="111";
    public final static String testPayment="הזן מספר כרטיס תקין";
    public  final static String CONFIG_FILE="target\\Config.xml";
    public final static String NAVIGATE_L_PAGE="https://www.next.co.il/en";
    public final static String CHROMEDRIVER_PATH="E:\\ruchama\\selenium\\chromedriver.exe";
    public final static String FILE_PATH="C:\\Java Projects\\extent.html";
    public final static String EXPECTED_TITLE_LOGIN_PAGE="Next Israel: Online Fashion, Kids Clothes & Homeware";
    public final static String NAVIGATE_HOME_PAGE="https://www.next.co.il/en/homeware";
    public final static String EXPECTED_TITLE_HOME_PAGE="Next Official Site: Online Fashion, Kids Clothes & Homeware";
    public final static String NAVIGATE_PRODUCT_PAGE="https://www.next.co.il/he/style/st026406/u12317#u12317";
    public final static String EXPECTED_PRODUCT_TITLE_PAGE="Next Israel";
   //
    // public  final static String CONFIG_FILE="C:\\Java Projects\\progectselenium\\urlData.xml";

}
